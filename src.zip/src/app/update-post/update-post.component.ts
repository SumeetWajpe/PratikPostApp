import { Component, OnInit } from '@angular/core';
import { Post } from '../post.model';
import { ActivatedRoute, Router } from '@angular/router';
import { PostsService } from '../posts.service';

@Component({
  selector: 'app-update-post',
  templateUrl: './update-post.component.html',
  styleUrls: ['./update-post.component.css']
})
export class UpdatePostComponent implements OnInit {

  thePostToBeUpdated:Post = new Post();
  constructor(public router:Router, public routerService:ActivatedRoute,public postServObj:PostsService) { }

  ngOnInit() {
    // get the post to be updated
    this.routerService.params.subscribe(
      p => {
        let thePostId = p.id;        
        this.thePostToBeUpdated = this.postServObj.allPostsFromService.find(post => post.id == thePostId);   
      }
    )
  }

}
