import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-successmessage',
  templateUrl: './successmessage.component.html',
  styleUrls: ['./successmessage.component.css']
})
export class SuccessmessageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
