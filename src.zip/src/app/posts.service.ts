import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Post } from './post.model';
import { Observable } from 'rxjs';
import {Comment} from './comment';

@Injectable()
export class PostsService{
  public allPostsFromService:Post[] = [];
    constructor(public httpServObj:HttpClient){

    }
    // Observables
    // getAllPosts():Observable<Post[]>{
    //     // make an AJAX request !
    //     return this.httpServObj.get("https://jsonplaceholder.typicode.com/posts");
    // return this.httpServObj.get<Post[]>("https://jsonplaceholder.typicode.com/posts");    
    // }
    addNewPost(thePostToBeAdded:Post):Observable<any>{
      return this.httpServObj.post(`https://jsonplaceholder.typicode.com/posts`,thePostToBeAdded);
    }

    updatePost(thePostToBeUpdated:Post):Observable<any>{
      return this.httpServObj.put(`https://jsonplaceholder.typicode.com/posts/${thePostToBeUpdated.id}`,thePostToBeUpdated);
    }
   

    // Using Promises
    getAllPosts():Promise<Post[]>{          
    return this.httpServObj.get<Post[]>("https://jsonplaceholder.typicode.com/posts").toPromise();    
    }

    getCommentsForPost(postId:number):Promise<Comment[]>{
      return this.httpServObj.get<Comment[]>(`https://jsonplaceholder.typicode.com/posts/${postId}/comments`).toPromise()
    }

    
}