import { Component, OnInit, Input } from '@angular/core';
import { Post } from '../post.model';
import { PostsService } from '../posts.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-create-post',
  templateUrl: './create-post.component.html',
  styleUrls: ['./create-post.component.css']
})
export class CreatePostComponent implements OnInit {
  @Input() newPost:Post = new Post();
  isOperationEdit:boolean=false;
  ensureOneClick:boolean = false;
  constructor(private currRoute:ActivatedRoute, private router:Router ,private postServObj:PostsService) { }

  ngOnInit() {
       this.currRoute.params.subscribe(
        p => {
          if(p.id){
            this.isOperationEdit = true;
          }
        }
      )
  }

  OnFormSubmit(f){
    this.ensureOneClick = true;  // This ensures that user does not click submit button multiple times
    if(f.valid && !this.isOperationEdit){
      this.postServObj.addNewPost(this.newPost).subscribe(
        response => {
          if(response.id === 101 ){
            console.log(response);
               this.router.navigate(['/successmessage']);
          }
        }
      )
    }
    else if(f.valid && this.isOperationEdit){
      this.postServObj.updatePost(this.newPost).subscribe(
        response => {
          if(response.id === this.newPost.id ){
            console.log(response);
               this.router.navigate(['/successmessage']);
          }
        }
      )
    }
    
  }

}
