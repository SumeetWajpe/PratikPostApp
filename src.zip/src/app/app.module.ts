import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { ListofpostComponent } from './listofpost/listofpost.component';
import { PostdetailsComponent } from './postdetails/postdetails.component';
import { CreatePostComponent } from './create-post/create-post.component';
import { UpdatePostComponent } from './update-post/update-post.component';
import { PostsService } from './posts.service';
import { SuccessmessageComponent } from './successmessage/successmessage.component';


@NgModule({
  declarations: [
    AppComponent,
    ListofpostComponent,
    PostdetailsComponent,
    CreatePostComponent,
    UpdatePostComponent,
    SuccessmessageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [PostsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
