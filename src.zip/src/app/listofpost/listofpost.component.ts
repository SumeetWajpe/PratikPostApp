import { Component, OnInit } from '@angular/core';
import { PostsService } from '../posts.service';
import { Post } from '../post.model';

@Component({
  selector: 'app-listofpost',
  templateUrl: './listofpost.component.html',
  styleUrls: ['./listofpost.component.css']
})
export class ListofpostComponent implements OnInit {
  allPosts: Post[] = [];
  constructor(public postsServObj: PostsService) {
    
  }


  ngOnInit() {
    var aPromise = this.postsServObj.getAllPosts();
    aPromise.then(
      (response) => {
        this.allPosts = response;
        this.postsServObj.allPostsFromService = response;
      },
      (err) => console.log(err)
    )
  }

}
