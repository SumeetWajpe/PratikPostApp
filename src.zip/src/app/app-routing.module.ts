import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListofpostComponent } from './listofpost/listofpost.component';
import { PostdetailsComponent } from './postdetails/postdetails.component';
import { CreatePostComponent } from './create-post/create-post.component';
import { SuccessmessageComponent } from './successmessage/successmessage.component';
import { UpdatePostComponent } from './update-post/update-post.component';

var routes:Routes = [ 
  {path:'',component:ListofpostComponent}, 
  {path:'newpost',component:CreatePostComponent}, 
  {path:'updatepost/:id',component:UpdatePostComponent},   
  {path:'postdetails/:id',component:PostdetailsComponent},  
  {path:'successmessage',component:SuccessmessageComponent}, 
  {path:'**',redirectTo:'/'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
