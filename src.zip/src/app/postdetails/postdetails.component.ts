import { Component, OnInit } from '@angular/core';
import { Post } from '../post.model';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../posts.service';
import { Comment } from '../comment';


@Component({
  selector: 'app-postdetails',
  templateUrl: './postdetails.component.html',
  styleUrls: ['./postdetails.component.css']
})
export class PostdetailsComponent implements OnInit {

  thePost:Post = new Post();
  allCommentsForPost:Comment[] = new Array<Comment>();

  constructor(public routerService:ActivatedRoute,public postServObj:PostsService) { }

  GetComments(){
    this.routerService.params.subscribe(
      p => {
        let thePostId = p.id;        
        this.thePost = this.postServObj.allPostsFromService.find(post => post.id == thePostId);   
        let aPromise = this.postServObj.getCommentsForPost(thePostId);
        aPromise.then(
          commentsReceived => this.allCommentsForPost = commentsReceived,
          err=> console.log('Error : ' ,err) // would log/report this error to server in practise
        );

      }
    );// eof subscribe
  }

  ngOnInit() {
    // If the user hits refresh on post-details
    if(!this.postServObj.allPostsFromService.length){     
      var aPromise = this.postServObj.getAllPosts();
      aPromise.then(
        (response) => {         
          this.postServObj.allPostsFromService = response;
          this.GetComments();
        },
        (err) => console.log(err)
      )
    }
    else{
      this.GetComments();      
    }
     
        
  }

}
